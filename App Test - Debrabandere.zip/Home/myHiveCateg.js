// import React from 'react';
// import { TouchableOpacity, Text, View, StyleSheet } from 'react-native-gesture-handler';



// export default function MyHiveCateg({navigation}){
//     return(
//         <View>
//             <Text>myShop Categories</Text>
//             <Text>Choose your shop:</Text>
//             <TouchableOpacity style={styles.button} title='Flowers' onPress={() => navigation.navigate('myHive Shop')}><Text>Flowers</Text></TouchableOpacity>
//             <TouchableOpacity style={styles.button} title='Cactus' onPress={() => navigation.navigate('myHive Shop2')}><Text>Cactus</Text></TouchableOpacity>
//             <TouchableOpacity style={styles.button} title='Seeds' onPress={() => navigation.navigate('myHive Shop3')}><Text>Seeds</Text></TouchableOpacity>
//         </View>

//     )
// }

// const styles = StyleSheet.create({
//     container: {
//       flex: 1,
//       backgroundColor: '#fff',
//       flexDirection: 'column',
//     },
//     button:{
//         width: 200,
//         height: 40,
//         justifyContent: 'center',
//         alignItems: 'center',
//         backgroundColor: '#ff6100',
//         borderRadius: 20,
//         marginTop: 20,
//         marginHorizontal: WIDTH/4,
//       },  
// })