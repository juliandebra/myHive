Utilizo las siguientes dependencias:

npm install -g expo-cli
npm install @react-native-async-storage/async-storage
npm install @react-navigation/native
npm install react-native-reanimated react-native-gesture-handler react-native-screens react-native-safe-area-context @react-native-community/masked-view
npm install @react-navigation/drawer
npm install react-native-gesture-handler

Creo que esas son todas. Espero que no genere error!